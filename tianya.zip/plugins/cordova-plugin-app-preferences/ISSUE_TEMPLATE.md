Issue:
_____


Please specify your environment

Plugin version:
  - [ ] released version: _____
  - [ ] repository master

Toolchain:
  - [ ] Cordova cli
  - [ ] Phonegap cli
  - [ ] Phonegap cloud
  - [ ] Ionic
  - [ ] Other: _____

Platforms affected:
  - [ ] Android
  - [ ] iOS/macOS
  - [ ] LocalStorage fallback for browser and blackberry
  - [ ] Windows and Windows Phone 8.1 and later
  - [ ] Windows Phone 8 and earlier (deprecated)

What the scope of your problem:
  - [ ] General functionality (store/fetch/remove/clearAll)
  - [ ] Suites
  - [ ] Cloud synchronization and events
  - [ ] Preferences pane generation and display



